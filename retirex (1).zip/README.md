# Retirex MVP
Backend + CIT mínimo para simular plan de retiro.

## Endpoints
POST /cotizar
